class UsersController < ApplicationController
  def index
    render plain: "Whats up"
  end
end